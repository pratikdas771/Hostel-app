<!DOCTYPE html>
<html>
    <header>
        <title>Hotel App</title>
        <link rel = 'icon' type = 'image/gif' href = 'https://st3.depositphotos.com/3867453/13387/v/600/depositphotos_133874120-stock-illustration-letter-h-logo-icon-design.jpg'/>
        <link rel = 'stylesheet' type = 'text/css' href = './public/style/style.css'/>
        <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
        <link rel = "icon" type = "image/gif" href = "https://cdn.dribbble.com/users/648258/screenshots/2231728/dribbble.gif"/>
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    </header>
    <body>
 