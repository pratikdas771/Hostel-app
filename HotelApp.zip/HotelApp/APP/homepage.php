<?php
    require_once('./partials/header.php');
    require_once('./session/session.php');
    require_once('./partials/nav.php');
?>
    <div class = 'homepage box'>
        <div class = 'box_1'>
            <div>
                <h1>Hotel App</h1>
                <p>
                    Good Rooms at affordable Prizes
                    Lorem ipsum dolor sit amet, 
                    consectetur adipiscing elit.
                    Suspendisse varius lacinia mauris,
                    ac pharetra orci laoreet ac.
                    Donec pretium lorem et nunc posuere tristique.
                    
                </p>
            </div>
        </div>
        <div class = 'box_2'>
            <h3>Hotel App</h3>
        </div>
        
    </div>
<?php
    require_once('./partials/footer.php');
?>